"use client"

import { useState } from "react"
import { IdentityBand } from "@/components/filing/identity-band"
import { IncomeBand } from "@/components/filing/income-band"
import { DeductionsBand } from "@/components/filing/deductions-band"
import { ComputationBand } from "@/components/filing/computation-band"
import { TaxPaidBand } from "@/components/filing/tax-paid-band"
import { BankBand } from "@/components/filing/bank-band"
import { FilingFooter } from "@/components/filing/filing-footer"
import { Sidebar } from "@/components/filing/sidebar"
import { CompletenessRibbon } from "@/components/filing/completeness-ribbon"

export default function FilingReportPage() {
  const [regime, setRegime] = useState<"old" | "new">("new")
  
  // Sample data - in production this would come from a database
  const userData = {
    name: "Vikram Sharma",
    pan: "ABCDE1234F",
    dob: "15-08-1990",
    ay: "2026-27",
    itrType: "ITR-1",
    email: "vikram@example.com",
    emailVerified: true,
  }

  const incomeData = {
    salary: {
      employer: "Acme Corp",
      gross: 1200000,
      tds: 80000,
      standardDeduction: 75000,
      netTaxable: 1125000,
    },
    houseProperty: null,
    otherSources: 0,
    totalIncome: 1200000,
  }

  const deductionsData = {
    section80C: {
      ppf: 50000,
      elss: 50000,
      lic: 50000,
      total: 150000,
      limit: 150000,
    },
    section80D: {
      healthInsurance: 25000,
      total: 25000,
      limit: 25000,
    },
    section80CCD1B: {
      nps: 0,
      total: 0,
      limit: 50000,
    },
    totalDeductions: 175000,
  }

  const taxPaidData = {
    tdsSalary: 80000,
    tdsOther: 0,
    advanceTax: 0,
    selfAssessmentTax: 0,
    total: 80000,
  }

  const bankData = {
    bankName: "HDFC Bank",
    accountNumber: "****4521",
    ifsc: "HDFC0001234",
  }

  const computation = calculateTax(incomeData, deductionsData, regime)

  const sections = [
    { id: "identity", label: "Identity", complete: true },
    { id: "income", label: "Income", complete: true },
    { id: "deductions", label: "Deductions", complete: true },
    { id: "computation", label: "Computation", complete: true },
    { id: "tax-paid", label: "Tax Paid", complete: true },
    { id: "bank", label: "Bank Account", complete: true },
    { id: "filing", label: "Filing", complete: true },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Completeness Ribbon - Mobile */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50">
        <CompletenessRibbon sections={sections} />
      </div>

      <div className="flex">
        {/* Main Document */}
        <main className="flex-1 lg:mr-[320px]">
          <div className="max-w-[680px] mx-auto px-4 py-6 lg:py-12 mt-2 lg:mt-0">
            {/* Document Header */}
            <header className="mb-8">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-sm">B</span>
                </div>
                <span className="text-xl font-semibold tracking-tight text-foreground">BurnBlack</span>
              </div>
              <h1 className="text-2xl lg:text-3xl font-bold text-foreground tracking-tight">
                Tax Filing Report
              </h1>
              <p className="text-muted-foreground mt-1">
                AY {userData.ay} · {userData.itrType} · {regime === "new" ? "New" : "Old"} Regime
              </p>
            </header>

            {/* Document Bands */}
            <div className="space-y-0">
              <IdentityBand userData={userData} />
              <IncomeBand incomeData={incomeData} />
              <DeductionsBand deductionsData={deductionsData} regime={regime} />
              <ComputationBand 
                computation={computation} 
                regime={regime}
                onRegimeChange={setRegime}
              />
              <TaxPaidBand taxPaidData={taxPaidData} />
              <BankBand bankData={bankData} />
              <FilingFooter 
                computation={computation}
                sections={sections}
              />
            </div>
          </div>
        </main>

        {/* Desktop Sidebar */}
        <Sidebar 
          computation={computation}
          regime={regime}
          sections={sections}
          onRegimeChange={setRegime}
        />
      </div>

      {/* Mobile Bottom Bar */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4 z-40">
        <div className="flex items-center justify-between max-w-[680px] mx-auto">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">
              {computation.result > 0 ? "Refund Due" : computation.result < 0 ? "Tax Payable" : "No Tax Due"}
            </p>
            <p className={`text-xl font-mono font-bold ${
              computation.result > 0 ? "text-success" : computation.result < 0 ? "text-destructive" : "text-foreground"
            }`}>
              ₹{Math.abs(computation.result).toLocaleString("en-IN")}
            </p>
          </div>
          <button className="bg-primary text-primary-foreground px-6 py-3 rounded-lg font-semibold text-sm hover:bg-primary/90 transition-colors">
            Submit Filing
          </button>
        </div>
      </div>

      {/* Bottom padding for mobile bottom bar */}
      <div className="h-24 lg:hidden" />
    </div>
  )
}

function calculateTax(
  _income: unknown,
  _deductions: unknown,
  regime: "old" | "new"
) {
  const grossIncome = 1200000
  const standardDeduction = 75000
  const grossTotalIncome = grossIncome - standardDeduction
  
  // In new regime, no deductions allowed
  const applicableDeductions = regime === "new" ? 0 : 175000
  const taxableIncome = grossTotalIncome - applicableDeductions

  // New regime slabs (2026-27)
  let tax = 0
  if (regime === "new") {
    if (taxableIncome <= 400000) {
      tax = 0
    } else if (taxableIncome <= 800000) {
      tax = (taxableIncome - 400000) * 0.05
    } else if (taxableIncome <= 1200000) {
      tax = 20000 + (taxableIncome - 800000) * 0.10
    } else if (taxableIncome <= 1600000) {
      tax = 60000 + (taxableIncome - 1200000) * 0.15
    } else if (taxableIncome <= 2000000) {
      tax = 120000 + (taxableIncome - 1600000) * 0.20
    } else if (taxableIncome <= 2400000) {
      tax = 200000 + (taxableIncome - 2000000) * 0.25
    } else {
      tax = 300000 + (taxableIncome - 2400000) * 0.30
    }
  } else {
    // Old regime slabs
    if (taxableIncome <= 250000) {
      tax = 0
    } else if (taxableIncome <= 500000) {
      tax = (taxableIncome - 250000) * 0.05
    } else if (taxableIncome <= 1000000) {
      tax = 12500 + (taxableIncome - 500000) * 0.20
    } else {
      tax = 112500 + (taxableIncome - 1000000) * 0.30
    }
  }

  // Rebate u/s 87A (if taxable income <= 7L in new regime, <= 5L in old)
  let rebate = 0
  if (regime === "new" && taxableIncome <= 700000 && tax <= 25000) {
    rebate = tax
  } else if (regime === "old" && taxableIncome <= 500000 && tax <= 12500) {
    rebate = tax
  }

  const taxAfterRebate = tax - rebate
  const cess = taxAfterRebate * 0.04
  const totalTax = taxAfterRebate + cess
  const tdsPaid = 80000
  const result = tdsPaid - totalTax // Positive = refund, negative = payable

  return {
    grossIncome,
    standardDeduction,
    grossTotalIncome,
    applicableDeductions,
    taxableIncome,
    tax,
    rebate,
    taxAfterRebate,
    cess,
    totalTax,
    tdsPaid,
    result,
    oldRegimeTax: regime === "old" ? totalTax : calculateOldRegimeTax(grossTotalIncome, 175000),
    newRegimeTax: regime === "new" ? totalTax : calculateNewRegimeTax(grossTotalIncome),
  }
}

function calculateOldRegimeTax(grossTotalIncome: number, deductions: number) {
  const taxableIncome = grossTotalIncome - deductions
  let tax = 0
  if (taxableIncome <= 250000) {
    tax = 0
  } else if (taxableIncome <= 500000) {
    tax = (taxableIncome - 250000) * 0.05
  } else if (taxableIncome <= 1000000) {
    tax = 12500 + (taxableIncome - 500000) * 0.20
  } else {
    tax = 112500 + (taxableIncome - 1000000) * 0.30
  }
  return tax * 1.04
}

function calculateNewRegimeTax(grossTotalIncome: number) {
  const taxableIncome = grossTotalIncome
  let tax = 0
  if (taxableIncome <= 400000) {
    tax = 0
  } else if (taxableIncome <= 800000) {
    tax = (taxableIncome - 400000) * 0.05
  } else if (taxableIncome <= 1200000) {
    tax = 20000 + (taxableIncome - 800000) * 0.10
  } else {
    tax = 60000 + (taxableIncome - 1200000) * 0.15
  }
  return tax * 1.04
}
