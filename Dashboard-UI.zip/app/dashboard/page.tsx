"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/header"
import { FinancialOverview } from "@/components/dashboard/financial-overview"
import { IncomeBreakdown } from "@/components/dashboard/income-breakdown"
import { TaxInsights } from "@/components/dashboard/tax-insights"
import { MonthlyTrend } from "@/components/dashboard/monthly-trend"
import { DeductionOptimizer } from "@/components/dashboard/deduction-optimizer"
import { YearComparison } from "@/components/dashboard/year-comparison"
import { QuickActions } from "@/components/dashboard/quick-actions"
import { DashboardSidebar } from "@/components/dashboard/dashboard-sidebar"

export default function DashboardPage() {
  const [selectedYear, setSelectedYear] = useState("2024-25")

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader selectedYear={selectedYear} onYearChange={setSelectedYear} />
      
      <div className="flex">
        {/* Sidebar - Desktop only */}
        <DashboardSidebar className="hidden lg:flex" />
        
        {/* Main Content */}
        <main className="flex-1 px-4 py-6 lg:px-8 lg:py-8">
          <div className="mx-auto max-w-7xl space-y-6">
            {/* Hero Section - Financial Overview */}
            <section className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
                <span className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
                  Your Financial Year
                </span>
              </div>
              <h1 className="text-2xl font-semibold tracking-tight text-foreground lg:text-3xl text-balance">
                FY {selectedYear} at a Glance
              </h1>
              <p className="text-sm text-muted-foreground max-w-2xl text-pretty">
                A comprehensive view of your income, deductions, and tax obligations. 
                Track your financial journey and optimize your returns.
              </p>
            </section>

            {/* Financial Overview Cards */}
            <FinancialOverview />

            {/* Charts Grid */}
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Income Sources */}
              <IncomeBreakdown />
              
              {/* Monthly Trend */}
              <MonthlyTrend />
            </div>

            {/* Tax Insights - Full Width */}
            <TaxInsights />

            {/* Deduction Optimizer & Year Comparison */}
            <div className="grid gap-6 lg:grid-cols-2">
              <DeductionOptimizer />
              <YearComparison />
            </div>

            {/* Quick Actions */}
            <QuickActions />
          </div>
        </main>
      </div>
    </div>
  )
}
