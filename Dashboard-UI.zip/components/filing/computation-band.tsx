"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"

interface ComputationData {
  grossIncome: number
  standardDeduction: number
  grossTotalIncome: number
  applicableDeductions: number
  taxableIncome: number
  tax: number
  rebate: number
  taxAfterRebate: number
  cess: number
  totalTax: number
  tdsPaid: number
  result: number
  oldRegimeTax: number
  newRegimeTax: number
}

interface ComputationBandProps {
  computation: ComputationData
  regime: "old" | "new"
  onRegimeChange: (regime: "old" | "new") => void
}

export function ComputationBand({ computation, regime, onRegimeChange }: ComputationBandProps) {
  const [showComparison, setShowComparison] = useState(false)

  const savings = Math.abs(computation.oldRegimeTax - computation.newRegimeTax)
  const betterRegime = computation.oldRegimeTax > computation.newRegimeTax ? "new" : "old"

  return (
    <section id="computation" className="border-b border-border py-6">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Computation
        </h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onRegimeChange("old")}
            className={`px-3 py-1 text-xs rounded-l-full border transition-colors ${
              regime === "old" 
                ? "bg-primary text-primary-foreground border-primary" 
                : "bg-secondary text-secondary-foreground border-border hover:bg-secondary/80"
            }`}
          >
            Old
          </button>
          <button
            onClick={() => onRegimeChange("new")}
            className={`px-3 py-1 text-xs rounded-r-full border transition-colors ${
              regime === "new" 
                ? "bg-primary text-primary-foreground border-primary" 
                : "bg-secondary text-secondary-foreground border-border hover:bg-secondary/80"
            }`}
          >
            New
          </button>
        </div>
      </div>

      {/* Computation Table */}
      <div className="font-mono text-sm bg-secondary/20 rounded-lg p-4 border border-border/50">
        <div className="space-y-1">
          {/* Gross Total Income */}
          <div className="flex justify-between">
            <span className="text-muted-foreground">Gross Total Income</span>
            <span className="text-foreground tabular-nums">₹{computation.grossTotalIncome.toLocaleString("en-IN")}</span>
          </div>
          
          {/* Deductions */}
          <div className="flex justify-between">
            <span className="text-muted-foreground">Less: Deductions</span>
            <span className={`tabular-nums ${regime === "new" ? "text-muted-foreground" : "text-foreground"}`}>
              {regime === "new" ? "₹0" : `₹${computation.applicableDeductions.toLocaleString("en-IN")}`}
            </span>
          </div>
          
          {/* Divider */}
          <div className="border-t border-border/50 my-2" />
          
          {/* Taxable Income */}
          <div className="flex justify-between font-medium">
            <span className="text-foreground">Taxable Income</span>
            <span className="text-foreground tabular-nums">₹{computation.taxableIncome.toLocaleString("en-IN")}</span>
          </div>
          
          <div className="h-3" />
          
          {/* Tax on Income */}
          <div className="flex justify-between">
            <span className="text-muted-foreground">Tax ({regime === "new" ? "New" : "Old"} Regime slabs)</span>
            <span className="text-foreground tabular-nums">₹{Math.round(computation.tax).toLocaleString("en-IN")}</span>
          </div>
          
          {/* Rebate */}
          {computation.rebate > 0 && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Less: Rebate 87A</span>
              <span className="text-success tabular-nums">−₹{Math.round(computation.rebate).toLocaleString("en-IN")}</span>
            </div>
          )}
          
          {/* Divider */}
          <div className="border-t border-border/50 my-2" />
          
          {/* Tax after Rebate */}
          <div className="flex justify-between">
            <span className="text-muted-foreground">Tax after Rebate</span>
            <span className="text-foreground tabular-nums">₹{Math.round(computation.taxAfterRebate).toLocaleString("en-IN")}</span>
          </div>
          
          {/* Cess */}
          <div className="flex justify-between">
            <span className="text-muted-foreground">Add: Cess 4%</span>
            <span className="text-foreground tabular-nums">₹{Math.round(computation.cess).toLocaleString("en-IN")}</span>
          </div>
          
          {/* Divider */}
          <div className="border-t border-border/50 my-2" />
          
          {/* Total Tax */}
          <div className="flex justify-between font-medium">
            <span className="text-foreground">Total Tax Liability</span>
            <span className="text-foreground tabular-nums">₹{Math.round(computation.totalTax).toLocaleString("en-IN")}</span>
          </div>
          
          {/* TDS */}
          <div className="flex justify-between">
            <span className="text-muted-foreground">Less: TDS</span>
            <span className="text-foreground tabular-nums">₹{computation.tdsPaid.toLocaleString("en-IN")}</span>
          </div>
          
          {/* Double Divider */}
          <div className="border-t-2 border-border my-2" />
          
          {/* Final Result */}
          <div className="flex justify-between text-lg font-bold">
            <span className={computation.result > 0 ? "text-success" : computation.result < 0 ? "text-destructive" : "text-foreground"}>
              {computation.result > 0 ? "REFUND" : computation.result < 0 ? "PAYABLE" : "NIL"}
            </span>
            <span className={`tabular-nums ${computation.result > 0 ? "text-success" : computation.result < 0 ? "text-destructive" : "text-foreground"}`}>
              ₹{Math.abs(Math.round(computation.result)).toLocaleString("en-IN")}
            </span>
          </div>
        </div>
      </div>

      {/* Regime Comparison */}
      <button
        onClick={() => setShowComparison(!showComparison)}
        className="mt-4 w-full flex items-center justify-between text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <span>
          Old Regime: ₹{Math.round(computation.oldRegimeTax).toLocaleString("en-IN")} tax · 
          New Regime: ₹{Math.round(computation.newRegimeTax).toLocaleString("en-IN")} tax · 
          <span className="text-success ml-1">
            {betterRegime === "new" ? "New" : "Old"} saves ₹{Math.round(savings).toLocaleString("en-IN")}
          </span>
        </span>
        {showComparison ? (
          <ChevronUp className="w-4 h-4" />
        ) : (
          <ChevronDown className="w-4 h-4" />
        )}
      </button>

      {showComparison && (
        <div className="animate-slide-up mt-3 p-4 bg-secondary/30 rounded-lg border border-border/50">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className={`p-3 rounded ${regime === "old" ? "bg-primary/20 border border-primary/50" : "bg-muted/50"}`}>
              <h4 className="font-medium text-foreground mb-2">Old Regime</h4>
              <p className="text-muted-foreground text-xs mb-2">Allows deductions under Chapter VI-A</p>
              <p className="font-mono text-lg">
                ₹{Math.round(computation.oldRegimeTax).toLocaleString("en-IN")}
                <span className="text-xs text-muted-foreground ml-1">tax</span>
              </p>
            </div>
            <div className={`p-3 rounded ${regime === "new" ? "bg-primary/20 border border-primary/50" : "bg-muted/50"}`}>
              <h4 className="font-medium text-foreground mb-2">New Regime</h4>
              <p className="text-muted-foreground text-xs mb-2">Lower slabs, no deductions</p>
              <p className="font-mono text-lg">
                ₹{Math.round(computation.newRegimeTax).toLocaleString("en-IN")}
                <span className="text-xs text-muted-foreground ml-1">tax</span>
              </p>
            </div>
          </div>
          <p className="text-center text-sm text-success mt-3">
            💡 {betterRegime === "new" ? "New" : "Old"} Regime saves you ₹{Math.round(savings).toLocaleString("en-IN")}
          </p>
        </div>
      )}
    </section>
  )
}
