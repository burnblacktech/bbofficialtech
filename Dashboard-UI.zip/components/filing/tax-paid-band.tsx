"use client"

import { useState } from "react"
import { Pencil, Check } from "lucide-react"

interface TaxPaidData {
  tdsSalary: number
  tdsOther: number
  advanceTax: number
  selfAssessmentTax: number
  total: number
}

interface TaxPaidBandProps {
  taxPaidData: TaxPaidData
}

export function TaxPaidBand({ taxPaidData }: TaxPaidBandProps) {
  const [editingField, setEditingField] = useState<string | null>(null)
  const [tempValue, setTempValue] = useState("")

  const handleEdit = (field: string, value: number) => {
    setEditingField(field)
    setTempValue(value.toString())
  }

  const handleSave = () => {
    // In production, this would update the database
    setEditingField(null)
  }

  const taxItems = [
    { id: "tdsSalary", label: "TDS - Salary (Acme Corp)", value: taxPaidData.tdsSalary },
    { id: "tdsOther", label: "TDS - Other", value: taxPaidData.tdsOther },
    { id: "advanceTax", label: "Advance Tax", value: taxPaidData.advanceTax },
    { id: "selfAssessmentTax", label: "Self-Assessment Tax", value: taxPaidData.selfAssessmentTax },
  ]

  return (
    <section id="tax-paid" className="border-b border-border py-6">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Tax Paid
        </h2>
      </div>

      {/* Tax Items */}
      <div className="font-mono text-sm space-y-2">
        {taxItems.map((item) => (
          <div key={item.id} className="group flex items-center justify-between py-1">
            <span className="text-muted-foreground">{item.label}</span>
            <div className="flex items-center gap-2">
              {editingField === item.id ? (
                <>
                  <input
                    type="number"
                    value={tempValue}
                    onChange={(e) => setTempValue(e.target.value)}
                    className="w-24 bg-input border border-border rounded px-2 py-1 text-right text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                    autoFocus
                  />
                  <button
                    onClick={handleSave}
                    className="text-primary hover:text-primary/80"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <>
                  <span className={`tabular-nums ${item.value > 0 ? "text-foreground" : "text-muted-foreground"}`}>
                    ₹{item.value.toLocaleString("en-IN")}
                  </span>
                  <button
                    onClick={() => handleEdit(item.id, item.value)}
                    className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground transition-opacity"
                  >
                    <Pencil className="w-3 h-3" />
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
        
        {/* Divider */}
        <div className="border-t border-border/50 my-2" />
        
        {/* Total */}
        <div className="flex items-center justify-between font-medium">
          <span className="text-foreground">Total</span>
          <span className="text-foreground tabular-nums">
            ₹{taxPaidData.total.toLocaleString("en-IN")}
          </span>
        </div>
      </div>
    </section>
  )
}
