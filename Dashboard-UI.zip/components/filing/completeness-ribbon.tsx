"use client"

interface Section {
  id: string
  label: string
  complete: boolean
}

interface CompletenessRibbonProps {
  sections: Section[]
}

export function CompletenessRibbon({ sections }: CompletenessRibbonProps) {
  const completeSections = sections.filter((s) => s.complete).length
  const totalSections = sections.length
  const percentage = (completeSections / totalSections) * 100

  return (
    <div className="h-1 bg-muted">
      <div 
        className={`h-full transition-all duration-500 ${
          percentage === 100 ? "bg-success" : "bg-primary"
        }`}
        style={{ width: `${percentage}%` }}
      />
    </div>
  )
}
