"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp, Plus, Briefcase } from "lucide-react"

export interface IncomeData {
  salary: {
    employer: string
    gross: number
    tds: number
    standardDeduction: number
    netTaxable: number
  } | null
  houseProperty: {
    type: string
    rent: number
    interest: number
    netIncome: number
  } | null
  otherSources: number
  totalIncome: number
}

interface IncomeBandProps {
  incomeData: IncomeData
}

export function IncomeBand({ incomeData }: IncomeBandProps) {
  const [expandedItem, setExpandedItem] = useState<string | null>(null)
  const [showAddPopover, setShowAddPopover] = useState(false)

  const toggleExpand = (item: string) => {
    setExpandedItem(expandedItem === item ? null : item)
  }

  return (
    <section id="income" className="border-b border-border py-6">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Income
        </h2>
        <span className="font-mono text-base text-foreground">
          ₹{incomeData.totalIncome.toLocaleString("en-IN")}
        </span>
      </div>

      {/* Income Items */}
      <div className="space-y-1">
        {/* Salary */}
        {incomeData.salary && (
          <div className="group">
            <button
              onClick={() => toggleExpand("salary")}
              className="w-full flex items-center justify-between py-2 hover:bg-secondary/30 rounded px-2 -mx-2 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded bg-success/20 flex items-center justify-center">
                  <Briefcase className="w-3 h-3 text-success" />
                </div>
                <div className="text-left">
                  <span className="text-foreground">Salary</span>
                  <span className="text-muted-foreground ml-2">·</span>
                  <span className="text-muted-foreground ml-2 text-sm">{incomeData.salary.employer}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-foreground">
                  ₹{incomeData.salary.gross.toLocaleString("en-IN")}
                </span>
                {expandedItem === "salary" ? (
                  <ChevronUp className="w-4 h-4 text-muted-foreground" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-muted-foreground" />
                )}
              </div>
            </button>
            
            {/* Expanded Details */}
            {expandedItem === "salary" && (
              <div className="animate-slide-up ml-9 mt-1 mb-3 p-3 bg-secondary/30 rounded-lg border border-border/50">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <label className="block text-xs text-muted-foreground mb-1">Gross Salary</label>
                    <input
                      type="text"
                      defaultValue={`₹${incomeData.salary.gross.toLocaleString("en-IN")}`}
                      className="w-full bg-input border border-border rounded px-2 py-1.5 font-mono text-sm text-right focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-muted-foreground mb-1">TDS Deducted</label>
                    <input
                      type="text"
                      defaultValue={`₹${incomeData.salary.tds.toLocaleString("en-IN")}`}
                      className="w-full bg-input border border-border rounded px-2 py-1.5 font-mono text-sm text-right focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-muted-foreground mb-1">Standard Deduction</label>
                    <input
                      type="text"
                      defaultValue={`₹${incomeData.salary.standardDeduction.toLocaleString("en-IN")}`}
                      className="w-full bg-input border border-border rounded px-2 py-1.5 font-mono text-sm text-right focus:outline-none focus:ring-2 focus:ring-primary"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-muted-foreground mb-1">Net Taxable</label>
                    <div className="w-full bg-muted/50 border border-border rounded px-2 py-1.5 font-mono text-sm text-right text-success">
                      ₹{incomeData.salary.netTaxable.toLocaleString("en-IN")}
                    </div>
                  </div>
                </div>
                <div className="flex justify-end mt-3">
                  <button 
                    onClick={() => setExpandedItem(null)}
                    className="bg-primary text-primary-foreground px-3 py-1.5 rounded text-xs font-medium hover:bg-primary/90 transition-colors"
                  >
                    Save
                  </button>
                </div>
              </div>
            )}
            
            {/* Detail line */}
            {expandedItem !== "salary" && (
              <p className="text-xs text-muted-foreground ml-9 mt-0.5">
                Gross ₹{incomeData.salary.gross.toLocaleString("en-IN")} · TDS ₹{incomeData.salary.tds.toLocaleString("en-IN")} · Net ₹{incomeData.salary.netTaxable.toLocaleString("en-IN")}
              </p>
            )}
          </div>
        )}

        {/* House Property (if applicable) */}
        {incomeData.houseProperty && (
          <div className="group">
            <button
              onClick={() => toggleExpand("property")}
              className="w-full flex items-center justify-between py-2 hover:bg-secondary/30 rounded px-2 -mx-2 transition-colors"
            >
              <span className="text-foreground">House Property</span>
              <span className="font-mono text-destructive">
                −₹{Math.abs(incomeData.houseProperty.netIncome).toLocaleString("en-IN")}
              </span>
            </button>
          </div>
        )}

        {/* Add Income Source */}
        <div className="relative mt-3">
          <button
            onClick={() => setShowAddPopover(!showAddPopover)}
            className="flex items-center gap-1 text-primary text-xs hover:text-primary/80 transition-colors"
          >
            <Plus className="w-3 h-3" />
            Add income source
          </button>
          
          {showAddPopover && (
            <>
              <div 
                className="fixed inset-0 bg-background/50 z-40"
                onClick={() => setShowAddPopover(false)}
              />
              <div className="absolute top-full left-0 mt-2 bg-popover border border-border rounded-lg shadow-lg p-3 z-50 w-64 animate-slide-up">
                <p className="text-xs text-muted-foreground mb-2">Select income type</p>
                <div className="space-y-1">
                  {["Salary", "House Property", "Capital Gains", "Business/Profession", "Other Sources"].map((type) => (
                    <button
                      key={type}
                      className="w-full text-left px-2 py-1.5 text-sm text-foreground hover:bg-secondary/50 rounded transition-colors"
                      onClick={() => setShowAddPopover(false)}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  )
}
