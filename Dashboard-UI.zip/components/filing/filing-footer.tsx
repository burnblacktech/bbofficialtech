"use client"

import { Download, FileJson, FileText, Printer, AlertCircle, CheckCircle2, ArrowRight } from "lucide-react"

interface ComputationData {
  result: number
  totalTax: number
  tdsPaid: number
}

interface Section {
  id: string
  label: string
  complete: boolean
}

interface FilingFooterProps {
  computation: ComputationData
  sections: Section[]
}

export function FilingFooter({ computation, sections }: FilingFooterProps) {
  const incompleteSections = sections.filter((s) => !s.complete)
  const isReady = incompleteSections.length === 0

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section id="filing" className="py-8">
      <div className="bg-secondary/50 rounded-xl p-6 border border-border">
        {isReady ? (
          <>
            {/* Ready State */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-success/20 flex items-center justify-center animate-breathe">
                <CheckCircle2 className="w-5 h-5 text-success" />
              </div>
              <div>
                <h3 className="text-foreground font-semibold">Ready to file</h3>
                <p className="text-sm text-muted-foreground">
                  All sections verified · {computation.result > 0 ? "Refund" : "Tax"}: ₹{Math.abs(computation.result).toLocaleString("en-IN")}
                </p>
              </div>
            </div>

            {/* Submit Button */}
            <button className="w-full bg-primary text-primary-foreground py-4 rounded-lg font-semibold text-base hover:bg-primary/90 transition-all hover:scale-[1.01] active:scale-[0.99] animate-pulse-gold hidden lg:flex items-center justify-center gap-2">
              Submit to Income Tax Department
              <ArrowRight className="w-5 h-5" />
            </button>

            {/* Secondary Actions */}
            <div className="flex items-center justify-center gap-6 mt-4 text-sm">
              <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                <FileJson className="w-4 h-4" />
                Download JSON
              </button>
              <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                <FileText className="w-4 h-4" />
                Download PDF
              </button>
              <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                <Printer className="w-4 h-4" />
                Print
              </button>
            </div>
          </>
        ) : (
          <>
            {/* Incomplete State */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-warning/20 flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-warning" />
              </div>
              <div>
                <h3 className="text-foreground font-semibold">Almost there</h3>
                <p className="text-sm text-muted-foreground">
                  {incompleteSections.length} section{incompleteSections.length > 1 ? "s" : ""} need{incompleteSections.length === 1 ? "s" : ""} your attention
                </p>
              </div>
            </div>

            {/* Blockers */}
            <div className="space-y-2 mb-4">
              {incompleteSections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className="w-full flex items-center gap-2 p-3 bg-warning/10 border border-warning/20 rounded-lg text-left hover:bg-warning/20 transition-colors"
                >
                  <span className="w-2 h-2 rounded-full bg-warning" />
                  <span className="text-sm text-foreground">Complete {section.label.toLowerCase()} section</span>
                </button>
              ))}
            </div>

            {/* Disabled Submit Button */}
            <button 
              disabled
              className="w-full bg-muted text-muted-foreground py-4 rounded-lg font-semibold text-base cursor-not-allowed hidden lg:block"
            >
              Submit to Income Tax Department
            </button>
          </>
        )}
      </div>

      {/* Legal Disclaimer */}
      <p className="text-xs text-muted-foreground text-center mt-6 max-w-md mx-auto">
        By submitting, you confirm that all information provided is accurate and complete to the best of your knowledge.
      </p>
    </section>
  )
}
