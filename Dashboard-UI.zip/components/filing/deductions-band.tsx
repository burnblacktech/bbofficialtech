"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp, AlertCircle } from "lucide-react"

export interface DeductionsData {
  section80C: {
    ppf: number
    elss: number
    lic: number
    total: number
    limit: number
  }
  section80D: {
    healthInsurance: number
    total: number
    limit: number
  }
  section80CCD1B: {
    nps: number
    total: number
    limit: number
  }
  totalDeductions: number
}

interface DeductionsBandProps {
  deductionsData: DeductionsData
  regime: "old" | "new"
}

export function DeductionsBand({ deductionsData, regime }: DeductionsBandProps) {
  const [expandedItem, setExpandedItem] = useState<string | null>(null)

  const toggleExpand = (item: string) => {
    setExpandedItem(expandedItem === item ? null : item)
  }

  const getProgressColor = (used: number, limit: number) => {
    if (used >= limit) return "text-success bg-success"
    if (used === 0) return "text-muted-foreground bg-muted"
    return "text-foreground bg-primary"
  }

  const deductions = [
    {
      id: "80C",
      code: "80C",
      description: "PPF, ELSS, LIC",
      used: deductionsData.section80C.total,
      limit: deductionsData.section80C.limit,
      details: deductionsData.section80C,
    },
    {
      id: "80D",
      code: "80D",
      description: "Health Insurance",
      used: deductionsData.section80D.total,
      limit: deductionsData.section80D.limit,
      details: deductionsData.section80D,
    },
    {
      id: "80CCD1B",
      code: "80CCD(1B)",
      description: "NPS",
      used: deductionsData.section80CCD1B.total,
      limit: deductionsData.section80CCD1B.limit,
      details: deductionsData.section80CCD1B,
      suggestion: deductionsData.section80CCD1B.total === 0 ? "Consider NPS for ₹50K additional tax-free investment." : null,
    },
  ]

  return (
    <section id="deductions" className="border-b border-border py-6">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Deductions
          </h2>
          {regime === "new" && (
            <span className="text-xs bg-warning/20 text-warning px-2 py-0.5 rounded">
              Not applicable in New Regime
            </span>
          )}
        </div>
        <span className={`font-mono text-base ${regime === "new" ? "text-muted-foreground line-through" : "text-foreground"}`}>
          ₹{deductionsData.totalDeductions.toLocaleString("en-IN")}
        </span>
      </div>

      {/* Deduction Items */}
      <div className={`space-y-1 ${regime === "new" ? "opacity-50" : ""}`}>
        {deductions.map((deduction) => {
          const progressPercent = Math.min((deduction.used / deduction.limit) * 100, 100)
          const colorClass = getProgressColor(deduction.used, deduction.limit)
          
          return (
            <div key={deduction.id} className="group">
              <button
                onClick={() => toggleExpand(deduction.id)}
                disabled={regime === "new"}
                className="w-full flex items-center justify-between py-2 hover:bg-secondary/30 rounded px-2 -mx-2 transition-colors disabled:cursor-not-allowed"
              >
                <div className="flex items-center gap-3">
                  <span className="text-foreground font-mono text-sm">{deduction.code}</span>
                  <span className="text-muted-foreground text-sm">·</span>
                  <span className="text-muted-foreground text-sm">{deduction.description}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`font-mono text-sm ${deduction.used >= deduction.limit ? "text-success" : deduction.used === 0 ? "text-muted-foreground" : "text-foreground"}`}>
                    ₹{deduction.used.toLocaleString("en-IN")} / ₹{deduction.limit.toLocaleString("en-IN")}
                  </span>
                  {expandedItem === deduction.id ? (
                    <ChevronUp className="w-4 h-4 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-muted-foreground" />
                  )}
                </div>
              </button>
              
              {/* Progress bar */}
              <div className="mx-2 h-1 bg-muted rounded-full overflow-hidden mt-1">
                <div 
                  className={`h-full rounded-full transition-all duration-300 ${colorClass}`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              
              {/* Expanded Details */}
              {expandedItem === deduction.id && regime !== "new" && (
                <div className="animate-slide-up mt-3 mb-3 p-3 bg-secondary/30 rounded-lg border border-border/50">
                  <div className="flex justify-between text-xs text-muted-foreground mb-3">
                    <span>Limit: ₹{deduction.limit.toLocaleString("en-IN")}</span>
                    <span>Used: ₹{deduction.used.toLocaleString("en-IN")}</span>
                    <span>Remaining: ₹{(deduction.limit - deduction.used).toLocaleString("en-IN")}</span>
                  </div>
                  
                  {deduction.id === "80C" && (
                    <div className="space-y-2">
                      {Object.entries(deduction.details).filter(([key]) => !["total", "limit"].includes(key)).map(([key, value]) => (
                        <div key={key} className="flex items-center justify-between">
                          <label className="text-sm text-muted-foreground capitalize">{key}</label>
                          <input
                            type="text"
                            defaultValue={`₹${(value as number).toLocaleString("en-IN")}`}
                            className="w-24 bg-input border border-border rounded px-2 py-1 font-mono text-xs text-right focus:outline-none focus:ring-2 focus:ring-primary"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {deduction.id === "80D" && (
                    <div className="flex items-center justify-between">
                      <label className="text-sm text-muted-foreground">Health Insurance Premium</label>
                      <input
                        type="text"
                        defaultValue={`₹${deduction.details.healthInsurance.toLocaleString("en-IN")}`}
                        className="w-24 bg-input border border-border rounded px-2 py-1 font-mono text-xs text-right focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                  )}
                  
                  {deduction.id === "80CCD1B" && (
                    <div className="flex items-center justify-between">
                      <label className="text-sm text-muted-foreground">NPS Contribution</label>
                      <input
                        type="text"
                        defaultValue={`₹${deduction.details.nps.toLocaleString("en-IN")}`}
                        className="w-24 bg-input border border-border rounded px-2 py-1 font-mono text-xs text-right focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                  )}
                  
                  {deduction.suggestion && (
                    <div className="mt-3 flex items-start gap-2 text-warning text-xs italic">
                      <AlertCircle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                      <span>{deduction.suggestion}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-end mt-3">
                    <button 
                      onClick={() => setExpandedItem(null)}
                      className="bg-primary text-primary-foreground px-3 py-1.5 rounded text-xs font-medium hover:bg-primary/90 transition-colors"
                    >
                      Save
                    </button>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </section>
  )
}
