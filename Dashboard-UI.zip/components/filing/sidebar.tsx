"use client"

import { Check, ArrowRight } from "lucide-react"

interface ComputationData {
  result: number
  totalTax: number
  tdsPaid: number
}

interface Section {
  id: string
  label: string
  complete: boolean
}

interface SidebarProps {
  computation: ComputationData
  regime: "old" | "new"
  sections: Section[]
  onRegimeChange: (regime: "old" | "new") => void
}

export function Sidebar({ computation, regime, sections, onRegimeChange }: SidebarProps) {
  const completeSections = sections.filter((s) => s.complete).length
  const totalSections = sections.length
  const isReady = completeSections === totalSections

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <aside className="hidden lg:block fixed right-0 top-0 h-screen w-[320px] border-l border-border bg-card p-6 overflow-y-auto">
      <div className="h-full flex flex-col">
        {/* Logo */}
        <div className="flex items-center gap-2 mb-8">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-sm">B</span>
          </div>
          <span className="text-lg font-semibold tracking-tight text-foreground">BurnBlack</span>
        </div>

        {/* Tax Result */}
        <div className="bg-secondary/50 rounded-xl p-5 mb-6 border border-border/50">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
            {computation.result > 0 ? "Refund Due" : computation.result < 0 ? "Tax Payable" : "No Tax Due"}
          </p>
          <p className={`text-3xl font-mono font-bold mb-3 ${
            computation.result > 0 ? "text-success" : computation.result < 0 ? "text-destructive" : "text-foreground"
          }`}>
            ₹{Math.abs(computation.result).toLocaleString("en-IN")}
          </p>
          
          {/* Regime Indicator */}
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Regime:</span>
            <div className="flex bg-muted rounded-full p-0.5">
              <button
                onClick={() => onRegimeChange("old")}
                className={`px-3 py-1 text-xs rounded-full transition-colors ${
                  regime === "old" 
                    ? "bg-primary text-primary-foreground" 
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Old
              </button>
              <button
                onClick={() => onRegimeChange("new")}
                className={`px-3 py-1 text-xs rounded-full transition-colors ${
                  regime === "new" 
                    ? "bg-primary text-primary-foreground" 
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                New
              </button>
            </div>
          </div>
        </div>

        {/* Completeness */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Completeness</span>
            <span className={`text-sm font-medium ${isReady ? "text-success" : "text-foreground"}`}>
              {completeSections} of {totalSections} ✓
            </span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${isReady ? "bg-success" : "bg-primary"}`}
              style={{ width: `${(completeSections / totalSections) * 100}%` }}
            />
          </div>
        </div>

        {/* Quick Nav */}
        <div className="flex-1">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Sections</p>
          <nav className="space-y-1">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => scrollToSection(section.id)}
                className="w-full flex items-center justify-between py-2 px-3 rounded-lg text-sm hover:bg-secondary/50 transition-colors group"
              >
                <span className={section.complete ? "text-foreground" : "text-muted-foreground"}>
                  {section.label}
                </span>
                {section.complete && (
                  <Check className="w-4 h-4 text-success" />
                )}
              </button>
            ))}
          </nav>
        </div>

        {/* File Button */}
        <div className="pt-6 border-t border-border mt-6">
          <button 
            disabled={!isReady}
            className={`w-full py-3 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
              isReady 
                ? "bg-primary text-primary-foreground hover:bg-primary/90 hover:scale-[1.02] active:scale-[0.98] animate-pulse-gold" 
                : "bg-muted text-muted-foreground cursor-not-allowed"
            }`}
          >
            Submit Filing
            <ArrowRight className="w-4 h-4" />
          </button>
          <p className="text-xs text-center text-muted-foreground mt-3">
            {isReady ? "All sections verified" : `${totalSections - completeSections} section${totalSections - completeSections > 1 ? "s" : ""} remaining`}
          </p>
        </div>
      </div>
    </aside>
  )
}
