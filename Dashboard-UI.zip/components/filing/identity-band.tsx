"use client"

import { useState } from "react"
import { Check, Pencil } from "lucide-react"

interface UserData {
  name: string
  pan: string
  dob: string
  ay: string
  itrType: string
  email: string
  emailVerified: boolean
}

interface IdentityBandProps {
  userData: UserData
}

export function IdentityBand({ userData }: IdentityBandProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editField, setEditField] = useState<"name" | "pan" | null>(null)
  const [tempValue, setTempValue] = useState("")

  const handleEdit = (field: "name" | "pan") => {
    setEditField(field)
    setTempValue(field === "name" ? userData.name : userData.pan)
    setIsEditing(true)
  }

  const handleSave = () => {
    // In production, this would update the database
    setIsEditing(false)
    setEditField(null)
  }

  return (
    <section id="identity" className="border-b border-border py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="group relative">
            {isEditing && editField === "name" ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={tempValue}
                  onChange={(e) => setTempValue(e.target.value)}
                  className="bg-input border border-border rounded px-2 py-1 text-foreground font-medium focus:outline-none focus:ring-2 focus:ring-primary"
                  autoFocus
                />
                <button
                  onClick={handleSave}
                  className="text-primary hover:text-primary/80"
                >
                  <Check className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleEdit("name")}
                className="flex items-center gap-1 text-foreground font-medium hover:text-primary transition-colors"
              >
                {userData.name}
                <Pencil className="w-3 h-3 opacity-0 group-hover:opacity-50" />
              </button>
            )}
          </div>
          
          <span className="text-muted-foreground">·</span>
          
          <div className="group relative">
            {isEditing && editField === "pan" ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={tempValue}
                  onChange={(e) => setTempValue(e.target.value.toUpperCase())}
                  className="bg-input border border-border rounded px-2 py-1 text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary w-28"
                  autoFocus
                  maxLength={10}
                />
                <button
                  onClick={handleSave}
                  className="text-primary hover:text-primary/80"
                >
                  <Check className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleEdit("pan")}
                className="flex items-center gap-1 font-mono text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                {userData.pan}
                {userData.emailVerified && (
                  <Check className="w-3 h-3 text-success" />
                )}
                <Pencil className="w-3 h-3 opacity-0 group-hover:opacity-50" />
              </button>
            )}
          </div>
          
          <span className="text-muted-foreground">·</span>
          
          <span className="text-sm text-muted-foreground">
            AY {userData.ay}
          </span>
        </div>

        {/* Regime Toggle - Hidden on mobile, shown in sidebar */}
        <div className="hidden lg:block">
          {/* Regime toggle moved to sidebar for better UX */}
        </div>
      </div>
    </section>
  )
}
