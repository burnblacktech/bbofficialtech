"use client"

import { useState } from "react"
import { Building2, Check, X } from "lucide-react"

interface BankData {
  bankName: string
  accountNumber: string
  ifsc: string
}

interface BankBandProps {
  bankData: BankData
}

export function BankBand({ bankData }: BankBandProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    bankName: bankData.bankName,
    accountNumber: "",
    ifsc: bankData.ifsc,
  })

  const handleSave = () => {
    // In production, this would update the database
    setIsEditing(false)
  }

  return (
    <section id="bank" className="border-b border-border py-6">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Refund To
        </h2>
      </div>

      {isEditing ? (
        <div className="animate-slide-up p-4 bg-secondary/30 rounded-lg border border-border/50">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-muted-foreground mb-1">Bank Name</label>
              <input
                type="text"
                value={formData.bankName}
                onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                className="w-full bg-input border border-border rounded px-3 py-2 text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">IFSC Code</label>
              <input
                type="text"
                value={formData.ifsc}
                onChange={(e) => setFormData({ ...formData, ifsc: e.target.value.toUpperCase() })}
                className="w-full bg-input border border-border rounded px-3 py-2 text-foreground font-mono focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs text-muted-foreground mb-1">Account Number</label>
              <input
                type="text"
                value={formData.accountNumber}
                onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                placeholder="Enter full account number"
                className="w-full bg-input border border-border rounded px-3 py-2 text-foreground font-mono focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-4">
            <button
              onClick={() => setIsEditing(false)}
              className="px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="bg-primary text-primary-foreground px-4 py-1.5 rounded text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              Save
            </button>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-info/20 flex items-center justify-center">
              <Building2 className="w-5 h-5 text-info" />
            </div>
            <div>
              <p className="text-foreground font-medium">{bankData.bankName}</p>
              <p className="text-sm text-muted-foreground font-mono">
                {bankData.accountNumber} · IFSC: {bankData.ifsc}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsEditing(true)}
            className="text-primary text-sm hover:text-primary/80 transition-colors"
          >
            Change
          </button>
        </div>
      )}
    </section>
  )
}
