"use client"

import { ArrowDownRight, ArrowUpRight, IndianRupee, TrendingUp, Wallet, PiggyBank, Receipt } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const metrics = [
  {
    label: "Gross Income",
    value: 18_45_000,
    change: +12.5,
    trend: "up",
    icon: Wallet,
    color: "text-chart-1",
    bgColor: "bg-chart-1/10",
  },
  {
    label: "Deductions Claimed",
    value: 2_50_000,
    change: +8.2,
    trend: "up",
    icon: PiggyBank,
    color: "text-info",
    bgColor: "bg-info/10",
  },
  {
    label: "Taxable Income",
    value: 15_95_000,
    change: +14.1,
    trend: "up",
    icon: TrendingUp,
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
  {
    label: "Tax Liability",
    value: 2_73_000,
    change: -5.3,
    trend: "down",
    icon: Receipt,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
]

function formatCurrency(value: number): string {
  if (value >= 10000000) {
    return `${(value / 10000000).toFixed(2)} Cr`
  }
  if (value >= 100000) {
    return `${(value / 100000).toFixed(2)} L`
  }
  return new Intl.NumberFormat("en-IN").format(value)
}

export function FinancialOverview() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {metrics.map((metric) => (
        <Card key={metric.label} className="overflow-hidden border-border bg-card">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  {metric.label}
                </p>
                <div className="flex items-baseline gap-1">
                  <IndianRupee className="h-4 w-4 text-muted-foreground" />
                  <span className="text-2xl font-semibold tabular-nums text-foreground">
                    {formatCurrency(metric.value)}
                  </span>
                </div>
              </div>
              <div className={`rounded-lg p-2 ${metric.bgColor}`}>
                <metric.icon className={`h-4 w-4 ${metric.color}`} />
              </div>
            </div>
            
            <div className="mt-3 flex items-center gap-1">
              {metric.trend === "up" ? (
                <ArrowUpRight className="h-3 w-3 text-success" />
              ) : (
                <ArrowDownRight className="h-3 w-3 text-destructive" />
              )}
              <span className={`text-xs font-medium ${metric.trend === "up" ? "text-success" : "text-destructive"}`}>
                {metric.change > 0 ? "+" : ""}{metric.change}%
              </span>
              <span className="text-xs text-muted-foreground">vs last year</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
