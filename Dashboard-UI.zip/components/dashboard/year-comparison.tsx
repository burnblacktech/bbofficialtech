"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, ResponsiveContainer, Tooltip, Cell } from "recharts"
import { ArrowUpRight, ArrowDownRight, Minus } from "lucide-react"

const yearData = [
  {
    year: "FY22",
    income: 1200000,
    tax: 145000,
    refund: 12000,
  },
  {
    year: "FY23",
    income: 1420000,
    tax: 178000,
    refund: 8500,
  },
  {
    year: "FY24",
    income: 1640000,
    tax: 218000,
    refund: -15000, // Payable
  },
  {
    year: "FY25",
    income: 1845000,
    tax: 273000,
    refund: 18200,
  },
]

const metrics = [
  {
    label: "Income Growth",
    current: 1845000,
    previous: 1640000,
    format: "currency",
  },
  {
    label: "Tax Rate (Effective)",
    current: 14.8,
    previous: 13.3,
    format: "percent",
  },
  {
    label: "Deduction Efficiency",
    current: 85,
    previous: 72,
    format: "percent",
  },
]

function formatCurrency(value: number): string {
  if (value >= 100000) {
    return `${(value / 100000).toFixed(1)}L`
  }
  if (value >= 1000) {
    return `${(value / 1000).toFixed(0)}K`
  }
  return value.toString()
}

function getChange(current: number, previous: number): { value: number; trend: "up" | "down" | "neutral" } {
  const change = ((current - previous) / previous) * 100
  return {
    value: Math.abs(change),
    trend: change > 0.5 ? "up" : change < -0.5 ? "down" : "neutral",
  }
}

export function YearComparison() {
  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          Year-over-Year Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Bar Chart */}
        <div className="h-36 mb-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={yearData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <XAxis
                dataKey="year"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload
                    return (
                      <div className="rounded-lg border border-border bg-popover px-3 py-2 shadow-lg">
                        <p className="text-xs font-medium text-foreground">{label}</p>
                        <p className="text-sm tabular-nums text-muted-foreground">
                          Income: {formatCurrency(data.income)}
                        </p>
                        <p className="text-sm tabular-nums text-muted-foreground">
                          Tax: {formatCurrency(data.tax)}
                        </p>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Bar dataKey="income" radius={[4, 4, 0, 0]}>
                {yearData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={
                      index === yearData.length - 1
                        ? "hsl(var(--primary))"
                        : "hsl(var(--muted))"
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Metrics */}
        <div className="space-y-3">
          {metrics.map((metric) => {
            const change = getChange(metric.current, metric.previous)
            const TrendIcon =
              change.trend === "up"
                ? ArrowUpRight
                : change.trend === "down"
                ? ArrowDownRight
                : Minus

            return (
              <div key={metric.label} className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{metric.label}</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium tabular-nums text-foreground">
                    {metric.format === "currency"
                      ? formatCurrency(metric.current)
                      : `${metric.current}%`}
                  </span>
                  <div
                    className={`flex items-center gap-0.5 text-xs ${
                      change.trend === "up"
                        ? "text-success"
                        : change.trend === "down"
                        ? "text-destructive"
                        : "text-muted-foreground"
                    }`}
                  >
                    <TrendIcon className="h-3 w-3" />
                    <span className="font-medium tabular-nums">{change.value.toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Summary */}
        <div className="mt-4 rounded-lg bg-primary/10 p-3">
          <p className="text-xs text-muted-foreground">
            <span className="font-medium text-foreground">4-Year Trend:</span> Your income has grown{" "}
            <span className="font-medium text-primary">53.75%</span> since FY22 while maintaining
            a consistent effective tax rate.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
