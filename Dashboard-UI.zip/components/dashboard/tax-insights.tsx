"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  TrendingDown, 
  Sparkles,
  IndianRupee,
  Calculator,
  Scale
} from "lucide-react"
import { Button } from "@/components/ui/button"

const taxComparison = {
  oldRegime: {
    taxable: 1345000,
    tax: 196000,
    cess: 7840,
    total: 203840,
  },
  newRegime: {
    taxable: 1595000,
    tax: 257000,
    cess: 10280,
    total: 267280,
  },
}

const savings = taxComparison.newRegime.total - taxComparison.oldRegime.total

const insights = [
  {
    type: "success",
    icon: CheckCircle2,
    title: "80C Fully Utilized",
    description: "You've claimed the maximum 1.5L deduction under Section 80C",
  },
  {
    type: "warning",
    icon: AlertCircle,
    title: "80D Underutilized",
    description: "You can claim additional 25K for health insurance premium",
  },
  {
    type: "info",
    icon: TrendingDown,
    title: "HRA Benefit Available",
    description: "Claim up to 60K more HRA based on your rent payments",
  },
]

function formatCurrency(value: number): string {
  if (value >= 100000) {
    return `${(value / 100000).toFixed(2)} L`
  }
  return new Intl.NumberFormat("en-IN").format(value)
}

export function TaxInsights() {
  return (
    <div className="space-y-4">
      {/* Section Header */}
      <div className="flex items-center gap-2">
        <Calculator className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
          Tax Analysis
        </h2>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Regime Comparison Card */}
        <Card className="border-border bg-card lg:col-span-2">
          <CardContent className="p-5">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Scale className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium text-foreground">Regime Comparison</span>
              </div>
              <Badge variant="secondary" className="bg-success/10 text-success border-0">
                <Sparkles className="mr-1 h-3 w-3" />
                Old Regime Recommended
              </Badge>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {/* Old Regime */}
              <div className="rounded-lg border-2 border-primary bg-primary/5 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Old Regime
                  </span>
                  <Badge className="bg-primary text-primary-foreground text-xs">
                    Best Choice
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Taxable Income</span>
                    <span className="font-medium tabular-nums text-foreground">
                      {formatCurrency(taxComparison.oldRegime.taxable)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Tax + Cess</span>
                    <span className="font-medium tabular-nums text-foreground">
                      {formatCurrency(taxComparison.oldRegime.total)}
                    </span>
                  </div>
                </div>
                <div className="mt-3 rounded-md bg-success/10 p-2 text-center">
                  <span className="text-xs font-medium text-success">
                    You save {formatCurrency(savings)}
                  </span>
                </div>
              </div>

              {/* New Regime */}
              <div className="rounded-lg border border-border bg-muted/30 p-4">
                <div className="mb-3">
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    New Regime
                  </span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Taxable Income</span>
                    <span className="font-medium tabular-nums text-foreground">
                      {formatCurrency(taxComparison.newRegime.taxable)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Tax + Cess</span>
                    <span className="font-medium tabular-nums text-foreground">
                      {formatCurrency(taxComparison.newRegime.total)}
                    </span>
                  </div>
                </div>
                <div className="mt-3 rounded-md bg-muted p-2 text-center">
                  <span className="text-xs text-muted-foreground">
                    Higher tax liability
                  </span>
                </div>
              </div>
            </div>

            {/* Summary Bar */}
            <div className="mt-4 flex items-center justify-between rounded-lg bg-muted/50 p-3">
              <div className="flex items-center gap-2">
                <IndianRupee className="h-4 w-4 text-success" />
                <span className="text-sm text-muted-foreground">
                  Potential Savings with Old Regime
                </span>
              </div>
              <span className="text-lg font-semibold tabular-nums text-success">
                + {formatCurrency(savings)}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Insights Card */}
        <Card className="border-border bg-card">
          <CardContent className="p-5">
            <div className="mb-4 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-foreground">Smart Insights</span>
            </div>

            <div className="space-y-3">
              {insights.map((insight, index) => (
                <div
                  key={index}
                  className={`rounded-lg p-3 ${
                    insight.type === "success"
                      ? "bg-success/10"
                      : insight.type === "warning"
                      ? "bg-warning/10"
                      : "bg-info/10"
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <insight.icon
                      className={`mt-0.5 h-4 w-4 shrink-0 ${
                        insight.type === "success"
                          ? "text-success"
                          : insight.type === "warning"
                          ? "text-warning"
                          : "text-info"
                      }`}
                    />
                    <div>
                      <p className="text-sm font-medium text-foreground">{insight.title}</p>
                      <p className="text-xs text-muted-foreground">{insight.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <Button variant="outline" size="sm" className="mt-4 w-full gap-2">
              View All Suggestions
              <ArrowRight className="h-3 w-3" />
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
