"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { 
  FileText, 
  Download, 
  Upload, 
  Calculator, 
  ArrowRight,
  Shield,
  Clock,
  Sparkles
} from "lucide-react"
import Link from "next/link"

const actions = [
  {
    icon: FileText,
    label: "File ITR",
    description: "Start your return filing",
    href: "/",
    primary: true,
  },
  {
    icon: Calculator,
    label: "Tax Calculator",
    description: "Estimate your liability",
    href: "#",
    primary: false,
  },
  {
    icon: Upload,
    label: "Upload Form 16",
    description: "Import salary details",
    href: "#",
    primary: false,
  },
  {
    icon: Download,
    label: "Download Reports",
    description: "Get computation sheets",
    href: "#",
    primary: false,
  },
]

const stats = [
  {
    icon: Shield,
    label: "Verified",
    value: "100%",
    description: "Data accuracy",
  },
  {
    icon: Clock,
    label: "Processing",
    value: "< 24h",
    description: "Average time",
  },
  {
    icon: Sparkles,
    label: "Savings",
    value: "63K+",
    description: "Identified this year",
  },
]

export function QuickActions() {
  return (
    <div className="space-y-4">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <h2 className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
            Quick Actions
          </h2>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-4">
        {/* Action Cards */}
        {actions.map((action) => (
          <Link key={action.label} href={action.href}>
            <Card
              className={`group cursor-pointer border-border transition-all hover:border-primary/50 ${
                action.primary ? "bg-primary hover:bg-primary/90" : "bg-card hover:bg-muted/50"
              }`}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div
                    className={`rounded-lg p-2 ${
                      action.primary ? "bg-primary-foreground/10" : "bg-muted"
                    }`}
                  >
                    <action.icon
                      className={`h-4 w-4 ${
                        action.primary ? "text-primary-foreground" : "text-foreground"
                      }`}
                    />
                  </div>
                  <ArrowRight
                    className={`h-4 w-4 opacity-0 transition-all group-hover:translate-x-1 group-hover:opacity-100 ${
                      action.primary ? "text-primary-foreground" : "text-muted-foreground"
                    }`}
                  />
                </div>
                <div className="mt-3">
                  <p
                    className={`text-sm font-medium ${
                      action.primary ? "text-primary-foreground" : "text-foreground"
                    }`}
                  >
                    {action.label}
                  </p>
                  <p
                    className={`text-xs ${
                      action.primary ? "text-primary-foreground/70" : "text-muted-foreground"
                    }`}
                  >
                    {action.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Stats Bar */}
      <Card className="border-border bg-muted/30">
        <CardContent className="p-4">
          <div className="grid grid-cols-3 gap-4">
            {stats.map((stat) => (
              <div key={stat.label} className="flex items-center gap-3">
                <div className="rounded-lg bg-background p-2">
                  <stat.icon className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-lg font-semibold tabular-nums text-foreground">
                    {stat.value}
                  </p>
                  <p className="text-xs text-muted-foreground">{stat.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* CTA */}
      <div className="flex items-center justify-center gap-4 pt-4">
        <p className="text-sm text-muted-foreground">
          Ready to file your return?
        </p>
        <Button className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90 animate-pulse-gold" asChild>
          <Link href="/">
            Start Filing Now
            <ArrowRight className="h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  )
}
