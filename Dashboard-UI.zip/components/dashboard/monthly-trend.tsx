"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts"

const monthlyData = [
  { month: "Apr", income: 125000, tds: 10800 },
  { month: "May", income: 125000, tds: 10800 },
  { month: "Jun", income: 130000, tds: 11300 },
  { month: "Jul", income: 130000, tds: 11300 },
  { month: "Aug", income: 135000, tds: 11900 },
  { month: "Sep", income: 135000, tds: 11900 },
  { month: "Oct", income: 140000, tds: 12500 },
  { month: "Nov", income: 140000, tds: 12500 },
  { month: "Dec", income: 145000, tds: 13200 },
  { month: "Jan", income: 145000, tds: 13200 },
  { month: "Feb", income: 150000, tds: 14000 },
  { month: "Mar", income: 150000, tds: 14000 },
]

function formatCurrency(value: number): string {
  if (value >= 100000) {
    return `${(value / 100000).toFixed(1)}L`
  }
  if (value >= 1000) {
    return `${(value / 1000).toFixed(0)}K`
  }
  return value.toString()
}

export function MonthlyTrend() {
  const totalIncome = monthlyData.reduce((acc, item) => acc + item.income, 0)
  const totalTds = monthlyData.reduce((acc, item) => acc + item.tds, 0)

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Monthly Cash Flow
          </CardTitle>
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <div className="h-2 w-2 rounded-full bg-chart-1" />
              <span className="text-muted-foreground">Income</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="h-2 w-2 rounded-full bg-primary" />
              <span className="text-muted-foreground">TDS</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Stats Row */}
        <div className="mb-4 grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-muted-foreground">Total Income</p>
            <p className="text-lg font-semibold tabular-nums text-chart-1">
              {formatCurrency(totalIncome)}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total TDS</p>
            <p className="text-lg font-semibold tabular-nums text-primary">
              {formatCurrency(totalTds)}
            </p>
          </div>
        </div>

        {/* Chart */}
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={monthlyData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="tdsGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--border))"
                vertical={false}
              />
              <XAxis
                dataKey="month"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }}
                tickFormatter={(value) => formatCurrency(value)}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="rounded-lg border border-border bg-popover px-3 py-2 shadow-lg">
                        <p className="text-xs font-medium text-muted-foreground">{label}</p>
                        {payload.map((entry, index) => (
                          <p key={index} className="text-sm font-semibold tabular-nums" style={{ color: entry.color }}>
                            {entry.name}: {formatCurrency(entry.value as number)}
                          </p>
                        ))}
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Area
                type="monotone"
                dataKey="income"
                name="Income"
                stroke="hsl(var(--chart-1))"
                strokeWidth={2}
                fill="url(#incomeGradient)"
              />
              <Area
                type="monotone"
                dataKey="tds"
                name="TDS"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                fill="url(#tdsGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Insight */}
        <div className="mt-4 rounded-lg bg-muted/50 p-3">
          <p className="text-xs text-muted-foreground">
            <span className="font-medium text-foreground">Trend:</span> Your income grew by{" "}
            <span className="font-medium text-success">20%</span> from Apr to Mar. 
            TDS deduction rate averaged <span className="font-medium text-primary">8.7%</span>.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
