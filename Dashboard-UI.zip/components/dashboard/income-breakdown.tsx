"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"
import { IndianRupee } from "lucide-react"

const incomeData = [
  { name: "Salary", value: 1500000, color: "hsl(var(--chart-1))" },
  { name: "Rental Income", value: 180000, color: "hsl(var(--chart-3))" },
  { name: "Interest", value: 125000, color: "hsl(var(--chart-4))" },
  { name: "Capital Gains", value: 40000, color: "hsl(var(--chart-2))" },
]

const totalIncome = incomeData.reduce((acc, item) => acc + item.value, 0)

function formatCurrency(value: number): string {
  if (value >= 100000) {
    return `${(value / 100000).toFixed(1)}L`
  }
  return new Intl.NumberFormat("en-IN").format(value)
}

export function IncomeBreakdown() {
  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Income Sources
          </CardTitle>
          <span className="text-xs text-muted-foreground">FY 2024-25</span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-6">
          {/* Donut Chart */}
          <div className="relative h-40 w-40 shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={incomeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={2}
                  dataKey="value"
                  stroke="none"
                >
                  {incomeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload
                      return (
                        <div className="rounded-lg border border-border bg-popover px-3 py-2 shadow-lg">
                          <p className="text-xs font-medium text-foreground">{data.name}</p>
                          <p className="text-sm font-semibold tabular-nums text-foreground">
                            {formatCurrency(data.value)}
                          </p>
                        </div>
                      )
                    }
                    return null
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            {/* Center Text */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-xs text-muted-foreground">Total</span>
              <span className="text-lg font-semibold tabular-nums text-foreground">
                {formatCurrency(totalIncome)}
              </span>
            </div>
          </div>

          {/* Legend */}
          <div className="flex-1 space-y-3">
            {incomeData.map((item) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-sm text-muted-foreground">{item.name}</span>
                </div>
                <div className="flex items-center gap-1 text-sm font-medium tabular-nums text-foreground">
                  <IndianRupee className="h-3 w-3 text-muted-foreground" />
                  {formatCurrency(item.value)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Insight */}
        <div className="mt-4 rounded-lg bg-muted/50 p-3">
          <p className="text-xs text-muted-foreground">
            <span className="font-medium text-foreground">Insight:</span> Your salary contributes{" "}
            <span className="font-medium text-primary">
              {((incomeData[0].value / totalIncome) * 100).toFixed(0)}%
            </span>{" "}
            of total income. Consider diversifying income streams.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
