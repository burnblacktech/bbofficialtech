"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { IndianRupee, Plus, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

const deductions = [
  {
    section: "80C",
    label: "Investments & Insurance",
    claimed: 150000,
    limit: 150000,
    items: ["ELSS", "PPF", "LIC Premium"],
  },
  {
    section: "80D",
    label: "Health Insurance",
    claimed: 25000,
    limit: 50000,
    items: ["Self & Family"],
  },
  {
    section: "80CCD(1B)",
    label: "NPS Contribution",
    claimed: 35000,
    limit: 50000,
    items: ["Additional NPS"],
  },
  {
    section: "24(b)",
    label: "Home Loan Interest",
    claimed: 0,
    limit: 200000,
    items: [],
  },
]

function formatCurrency(value: number): string {
  if (value >= 100000) {
    return `${(value / 100000).toFixed(1)}L`
  }
  if (value >= 1000) {
    return `${(value / 1000).toFixed(0)}K`
  }
  return value.toString()
}

export function DeductionOptimizer() {
  const totalClaimed = deductions.reduce((acc, d) => acc + d.claimed, 0)
  const totalLimit = deductions.reduce((acc, d) => acc + d.limit, 0)
  const potentialSavings = deductions.reduce((acc, d) => acc + (d.limit - d.claimed), 0)

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Deduction Optimizer
          </CardTitle>
          <div className="flex items-center gap-1 text-xs">
            <Zap className="h-3 w-3 text-primary" />
            <span className="text-muted-foreground">
              <span className="font-medium text-primary">{formatCurrency(potentialSavings)}</span> potential savings
            </span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Overall Progress */}
        <div className="mb-4 rounded-lg bg-muted/50 p-3">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="text-muted-foreground">Total Deductions Utilized</span>
            <span className="font-medium text-foreground">
              {formatCurrency(totalClaimed)} / {formatCurrency(totalLimit)}
            </span>
          </div>
          <Progress 
            value={(totalClaimed / totalLimit) * 100} 
            className="h-2 bg-muted"
          />
          <p className="mt-2 text-xs text-muted-foreground">
            You&apos;ve utilized <span className="font-medium text-foreground">{((totalClaimed / totalLimit) * 100).toFixed(0)}%</span> of available deductions
          </p>
        </div>

        {/* Section-wise Breakdown */}
        <div className="space-y-3">
          {deductions.map((deduction) => {
            const percentage = (deduction.claimed / deduction.limit) * 100
            const isComplete = percentage >= 100
            const isUnused = percentage === 0

            return (
              <div
                key={deduction.section}
                className={`rounded-lg border p-3 ${
                  isComplete
                    ? "border-success/30 bg-success/5"
                    : isUnused
                    ? "border-border bg-muted/30"
                    : "border-warning/30 bg-warning/5"
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-medium text-muted-foreground">
                        {deduction.section}
                      </span>
                      <span className="text-sm font-medium text-foreground">
                        {deduction.label}
                      </span>
                    </div>
                    {deduction.items.length > 0 && (
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {deduction.items.join(" • ")}
                      </p>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-0.5 text-sm font-medium tabular-nums text-foreground">
                      <IndianRupee className="h-3 w-3 text-muted-foreground" />
                      {formatCurrency(deduction.claimed)}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      of {formatCurrency(deduction.limit)}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Progress
                    value={percentage}
                    className={`h-1.5 flex-1 ${
                      isComplete ? "[&>div]:bg-success" : isUnused ? "" : "[&>div]:bg-warning"
                    }`}
                  />
                  <span
                    className={`text-xs font-medium tabular-nums ${
                      isComplete
                        ? "text-success"
                        : isUnused
                        ? "text-muted-foreground"
                        : "text-warning"
                    }`}
                  >
                    {percentage.toFixed(0)}%
                  </span>
                </div>
              </div>
            )
          })}
        </div>

        <Button variant="outline" size="sm" className="mt-4 w-full gap-2">
          <Plus className="h-3 w-3" />
          Add New Deduction
        </Button>
      </CardContent>
    </Card>
  )
}
