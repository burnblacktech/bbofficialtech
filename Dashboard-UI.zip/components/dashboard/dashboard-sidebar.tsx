"use client"

import { cn } from "@/lib/utils"
import { 
  LayoutDashboard, 
  FileText, 
  FolderOpen, 
  BarChart3, 
  Settings, 
  HelpCircle,
  ChevronRight,
  Flame,
  IndianRupee
} from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

interface DashboardSidebarProps {
  className?: string
}

const navigation = [
  {
    label: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
    active: true,
  },
  {
    label: "My Returns",
    href: "/",
    icon: FileText,
    badge: "1 Draft",
  },
  {
    label: "Documents",
    href: "#",
    icon: FolderOpen,
  },
  {
    label: "Reports",
    href: "#",
    icon: BarChart3,
  },
]

const secondaryNav = [
  {
    label: "Settings",
    href: "#",
    icon: Settings,
  },
  {
    label: "Help & Support",
    href: "#",
    icon: HelpCircle,
  },
]

export function DashboardSidebar({ className }: DashboardSidebarProps) {
  return (
    <aside
      className={cn(
        "sticky top-14 h-[calc(100vh-3.5rem)] w-64 shrink-0 flex-col border-r border-border bg-sidebar px-3 py-4",
        className
      )}
    >
      {/* Tax Summary Card */}
      <div className="rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 p-4 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <div className="rounded-full bg-primary/20 p-1.5">
            <Flame className="h-3 w-3 text-primary" />
          </div>
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Tax Status
          </span>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">Expected Refund</p>
          <div className="flex items-center gap-1">
            <IndianRupee className="h-5 w-5 text-success" />
            <span className="text-2xl font-semibold tabular-nums text-success">
              18,200
            </span>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-2">
          <Badge variant="secondary" className="bg-success/10 text-success border-0 text-xs">
            Refund Eligible
          </Badge>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1">
        {navigation.map((item) => (
          <Link
            key={item.label}
            href={item.href}
            className={cn(
              "group flex items-center justify-between rounded-lg px-3 py-2 text-sm transition-colors",
              item.active
                ? "bg-sidebar-accent text-sidebar-accent-foreground"
                : "text-sidebar-foreground hover:bg-sidebar-accent/50"
            )}
          >
            <div className="flex items-center gap-3">
              <item.icon className="h-4 w-4" />
              <span>{item.label}</span>
            </div>
            {item.badge ? (
              <Badge variant="secondary" className="text-xs">
                {item.badge}
              </Badge>
            ) : (
              <ChevronRight className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-100" />
            )}
          </Link>
        ))}
      </nav>

      <Separator className="my-4" />

      {/* Secondary Navigation */}
      <nav className="space-y-1">
        {secondaryNav.map((item) => (
          <Link
            key={item.label}
            href={item.href}
            className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-sidebar-foreground transition-colors hover:bg-sidebar-accent/50"
          >
            <item.icon className="h-4 w-4" />
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>

      {/* Footer */}
      <div className="mt-4 rounded-lg bg-muted/50 p-3">
        <p className="text-xs text-muted-foreground">
          Need help with your return?
        </p>
        <Link
          href="#"
          className="mt-1 inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
        >
          Talk to a Tax Expert
          <ChevronRight className="h-3 w-3" />
        </Link>
      </div>
    </aside>
  )
}
